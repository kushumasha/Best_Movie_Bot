BOT_TOKEN = "your_bot_token_here"
API_ID = 12345678
API_HASH = "your_api_hash"
CHANNEL_USERNAME = "your_channel_username"
